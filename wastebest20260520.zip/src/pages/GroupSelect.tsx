import { useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Layout } from "@/components/Layout";
import { useI18n } from "@/i18n/I18nProvider";
import { useSubmission, Group } from "@/state/SubmissionContext";
import { Button } from "@/components/ui/button";
import { Factory, Building2, ArrowRight } from "lucide-react";

const GroupSelect = () => {
  const { t } = useI18n();
  const { data, setGroup, reset } = useSubmission();
  const navigate = useNavigate();

  // When the user lands on the selection page, start a fresh submission so
  // changing groups doesn't carry stale answers.
  useEffect(() => {
    if (data.contact.acceptedTerms) reset();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const choose = (g: Group) => {
    setGroup(g);
  };

  return (
    <Layout>
      <div className="container max-w-4xl py-14 md:py-20">
        <div className="text-center mb-10">
          <h1 className="text-3xl md:text-4xl font-bold text-primary-deep">{t.select.title}</h1>
          <p className="mt-2 text-muted-foreground">{t.select.subtitle}</p>
        </div>

        <div className="grid md:grid-cols-2 gap-5">
          <Card
            selected={data.group === "A"}
            tone="grey"
            icon={<Factory className="w-7 h-7" />}
            question={t.select.questionA}
            title={t.select.groupA}
            desc={t.select.groupADesc}
            onClick={() => choose("A")}
          />
          <Card
            selected={data.group === "B"}
            tone="green"
            icon={<Building2 className="w-7 h-7" />}
            question={t.select.questionB}
            title={t.select.groupB}
            desc={t.select.groupBDesc}
            onClick={() => choose("B")}
          />
        </div>

        <p className="text-center text-sm text-muted-foreground mt-6">{t.select.onlyOne}</p>

        <div className="flex justify-center mt-8">
          <Button
            size="lg"
            disabled={!data.group}
            onClick={() => navigate("/questionnaire")}
            className="bg-primary hover:bg-primary-deep shadow-elegant"
          >
            {t.select.continue} <ArrowRight className="ml-1" />
          </Button>
        </div>

        <div className="text-center mt-4">
          <Link to="/" className="text-sm text-muted-foreground hover:text-primary">
            ← {t.nav.home}
          </Link>
        </div>
      </div>
    </Layout>
  );
};

const Card = ({
  selected,
  tone,
  icon,
  question,
  title,
  desc,
  onClick,
}: {
  selected: boolean;
  tone: "grey" | "green";
  icon: React.ReactNode;
  question: string;
  title: string;
  desc: string;
  onClick: () => void;
}) => {
  const ring = selected
    ? tone === "grey"
      ? "ring-2 ring-group-a-accent shadow-elegant"
      : "ring-2 ring-primary shadow-elegant"
    : "hover:shadow-elegant hover:-translate-y-1";

  const badge =
    tone === "grey"
      ? "bg-group-a-accent text-group-a-accent-foreground"
      : "bg-primary text-primary-foreground";

  return (
    <button
      
      type="button"
      onClick={onClick}
      aria-pressed={selected}
      className={`text-left bg-gradient-card rounded-2xl p-6 border border-border/50 shadow-soft transition-smooth ${ring}`}
    >
      <div className={`w-12 h-12 rounded-xl flex items-center justify-center mb-4 ${badge}`}>{icon}</div>
      <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">{question}</p>
      <h3 className="font-semibold text-lg text-primary-deep mb-1">{title}</h3>
      <p className="text-sm text-muted-foreground">{desc}</p>
    </button>
  );
};

export default GroupSelect;
