import { Slide } from "@/components/Slider";

const slidesData: Slide[] = [
  {
    url: '/slider/slide1.png',
    caption: 'Bridging the Gap: Connecting Industrial Waste Producers with Global Recyclers',
    type: 'image'
  },
  {
    url: '/slider/slide2.png',
    caption: 'Closing the Loop: Transforming Industrial Output into Valuable Resources',
    type: 'image'
  },
  {
    url: '/slider/slide3.png',
    caption: 'Driving Sustainability Through Efficient Waste-to-Resource Solutions',
    type: 'image' 
  },
  {
    url: '/slider/slide4.png',
    caption: 'Your Strategic Partner in Building a Greener, Zero-Waste Industry',
    type: 'image'
  }
];

export default slidesData;
