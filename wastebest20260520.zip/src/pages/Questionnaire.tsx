import { useMemo, useState } from "react";
import { Navigate, useNavigate } from "react-router-dom";
import { Layout } from "@/components/Layout";
import { useI18n } from "@/i18n/I18nProvider";
import { useSubmission, Region } from "@/state/SubmissionContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { MunicipalityCombobox } from "@/components/MunicipalityCombobox";
import { isValidPostal, isValidEmail, isValidPhone } from "@/lib/validation";
import { toast } from "sonner";
import { Factory, Building2, ArrowLeft, ArrowRight, Send } from "lucide-react";

const Questionnaire = () => {
  const { t } = useI18n();
  const { data, update } = useSubmission();
  const navigate = useNavigate();
  const [step, setStep] = useState(0);

  if (!data.group) return <Navigate to="/select" replace />;

  const isA = data.group === "A";
  const tone = isA ? "grey" : "green";

  // Steps: 0 Responsibility, 1 Subcategory, 2 Location, 3 Products, 4 Group-specific, 5 Contact
  const totalSteps = 6;

  const accentRing = isA ? "ring-group-a-accent" : "ring-primary";
  const accentBtn = isA
    ? "bg-group-a-accent hover:bg-group-a-accent/90 text-group-a-accent-foreground"
    : "bg-primary hover:bg-primary-deep text-primary-foreground";
  const accentBar = isA ? "[&>div]:bg-group-a-accent" : "[&>div]:bg-primary";

  // ---------- Validation per step ----------
  const c = data.common;
  const responsibilityValid =
    c.responsibility.owner ||
    c.responsibility.rd ||
    c.responsibility.hse ||
    (c.responsibility.other && c.responsibility.otherText.trim().length > 0);

  const stepValid = (() => {
    switch (step) {
      case 0:
        return responsibilityValid;
      case 1:
        return c.subcategory.length > 0;
      case 2:
        return c.region !== "" && c.municipality.length > 0 && isValidPostal(c.postal);
      case 3:
        return c.products.trim().length > 0;
      case 4:
        if (isA) {
          const a = data.groupA;
          return (
            a.wasteType.trim().length > 0 &&
            a.wasteForm !== "" &&
            a.hasAnalysis !== "" &&
            a.monthlyTons.trim().length > 0
          );
        } else {
          const b = data.groupB;
          return b.rawMaterials.trim().length > 0 && b.interest !== "";
        }
      case 5: {
        const ct = data.contact;
        return isValidEmail(ct.email) && isValidPhone(ct.phone) && ct.acceptedTerms;
      }
      default:
        return false;
    }
  })();

  const next = () => {
    if (!stepValid) {
      toast.error(t.quest.required);
      return;
    }
    setStep((s) => Math.min(s + 1, totalSteps - 1));
  };

  const back = () => setStep((s) => Math.max(s - 1, 0));

  const submit = () => {
    if (!stepValid) {
      toast.error(t.quest.required);
      return;
    }
    // Phase 1: no backend — store locally and route to confirmation.
    // Submission is persisted in localStorage by the provider; reset on /thank-you.
    navigate("/thank-you");
  };

  // ---------- Subcategory options ----------
  const subOptions = isA
    ? Object.entries(t.quest.subA).map(([key, label]) => ({ key, label }))
    : Object.entries(t.quest.subB).map(([key, label]) => ({ key, label }));

  return (
    <Layout>
      <div className="container max-w-2xl py-10 md:py-14">
        <div className="bg-gradient-card border border-border/50 rounded-2xl p-6 md:p-8 shadow-soft">
          {/* Header */}
          <div className="flex items-center gap-3 mb-2">
            <div
              className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                isA
                  ? "bg-group-a-accent text-group-a-accent-foreground"
                  : "bg-primary text-primary-foreground"
              }`}
            >
              {isA ? <Factory className="w-5 h-5" /> : <Building2 className="w-5 h-5" />}
            </div>
            <div className="flex-1">
              <h1 className="text-xl md:text-2xl font-bold text-primary-deep leading-tight">
                {isA ? t.quest.titleA : t.quest.titleB}
              </h1>
            </div>
            <span className="text-xs md:text-sm text-muted-foreground whitespace-nowrap">
              {t.quest.step} {step + 1} {t.quest.of} {totalSteps}
            </span>
          </div>

          <Progress value={((step + 1) / totalSteps) * 100} className={`mb-6 ${accentBar}`} />

          <div className="min-h-[260px]">
            {step === 0 && <ResponsibilityStep />}
            {step === 1 && <SubcategoryStep options={subOptions} />}
            {step === 2 && <LocationStep />}
            {step === 3 && <ProductsStep />}
            {step === 4 && (isA ? <GroupAStep /> : <GroupBStep />)}
            {step === 5 && <ContactStep />}
          </div>

          <div className="flex gap-2 mt-8">
            <Button variant="outline" onClick={back} disabled={step === 0}>
              <ArrowLeft className="w-4 h-4 mr-1" /> {t.quest.back}
            </Button>
            {step < totalSteps - 1 ? (
              <Button className={`flex-1 ${accentBtn}`} onClick={next}>
                {t.quest.next} <ArrowRight className="w-4 h-4 ml-1" />
              </Button>
            ) : (
              <Button className={`flex-1 ${accentBtn}`} onClick={submit}>
                <Send className="w-4 h-4 mr-1" /> {t.contact.submit}
              </Button>
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
};

// =================== Step components ===================

const ResponsibilityStep = () => {
  const { t } = useI18n();
  const { data, update } = useSubmission();
  const r = data.common.responsibility;
  const set = (patch: Partial<typeof r>) =>
    update("common", { ...data.common, responsibility: { ...r, ...patch } });

  return (
    <div className="space-y-4">
      <div>
        <Label className="text-base">{t.quest.respTitle}</Label>
        <p className="text-xs text-muted-foreground mt-0.5">{t.quest.respHelp}</p>
      </div>
      <div className="space-y-2">
        <CheckRow label={t.quest.respOwner} checked={r.owner} onChange={(v) => set({ owner: v })} />
        <CheckRow label={t.quest.respRD} checked={r.rd} onChange={(v) => set({ rd: v })} />
        <CheckRow label={t.quest.respHSE} checked={r.hse} onChange={(v) => set({ hse: v })} />
        <CheckRow label={t.quest.respOther} checked={r.other} onChange={(v) => set({ other: v })} />
        {r.other && (
          <Input
            value={r.otherText}
            onChange={(e) => set({ otherText: e.target.value })}
            placeholder={t.quest.respOtherPlaceholder}
            maxLength={120}
          />
        )}
      </div>
    </div>
  );
};

const SubcategoryStep = ({ options }: { options: { key: string; label: string }[] }) => {
  const { t } = useI18n();
  const { data, update } = useSubmission();
  return (
    <div className="space-y-4">
      <Label className="text-base">{t.quest.subcatTitle}</Label>
      <RadioGroup
        value={data.common.subcategory}
        onValueChange={(v) => update("common", { ...data.common, subcategory: v })}
        className="grid sm:grid-cols-2 gap-2"
      >
        {options.map(({ key, label }) => (
          <label
            key={key}
            className="flex items-center gap-2 p-3 rounded-lg border border-border hover:bg-accent/50 cursor-pointer"
          >
            <RadioGroupItem value={key} />
            <span className="text-sm">{label}</span>
          </label>
        ))}
      </RadioGroup>
    </div>
  );
};

const LocationStep = () => {
  const { t } = useI18n();
  const { data, update } = useSubmission();
  const c = data.common;
  const postalErr = c.postal.length > 0 && !isValidPostal(c.postal);

  const setCommon = (patch: Partial<typeof c>) => update("common", { ...c, ...patch });

  const regionOptions: { value: Region; label: string }[] = [
    { value: "N", label: t.quest.regionN },
    { value: "S", label: t.quest.regionS },
    { value: "E", label: t.quest.regionE },
    { value: "W", label: t.quest.regionW },
  ];

  return (
    <div className="space-y-4">
      <Label className="text-base">{t.quest.locTitle}</Label>

      <div className="space-y-1.5">
        <Label className="text-sm">{t.quest.region}</Label>
        <Select value={c.region} onValueChange={(v) => setCommon({ region: v as Region })}>
          <SelectTrigger>
            <SelectValue placeholder="—" />
          </SelectTrigger>
          <SelectContent>
            {regionOptions.map((r) => (
              <SelectItem key={r.value} value={r.value}>
                {r.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-1.5">
        <Label className="text-sm">{t.quest.municipality}</Label>
        <MunicipalityCombobox
          value={c.municipality}
          onChange={(v) => setCommon({ municipality: v })}
          placeholder="—"
          searchPlaceholder={t.quest.municipalitySearch}
        />
      </div>

      <div className="space-y-1.5">
        <Label className="text-sm">{t.quest.postal}</Label>
        <Input
          value={c.postal}
          onChange={(e) => setCommon({ postal: e.target.value.toUpperCase().replace(/\s+/g, "").slice(0, 6) })}
          placeholder="2628VP"
          maxLength={6}
          aria-invalid={postalErr}
          className={postalErr ? "border-destructive" : ""}
        />
        <p className={`text-xs ${postalErr ? "text-destructive" : "text-muted-foreground"}`}>
          {postalErr ? t.quest.postalInvalid : t.quest.postalHelp}
        </p>
      </div>
    </div>
  );
};

const ProductsStep = () => {
  const { t } = useI18n();
  const { data, update } = useSubmission();
  return (
    <div className="space-y-3">
      <Label className="text-base">{t.quest.productsTitle}</Label>
      <Label className="text-sm font-normal text-muted-foreground">{t.quest.products}</Label>
      <Textarea
        value={data.common.products}
        onChange={(e) => update("common", { ...data.common, products: e.target.value })}
        rows={5}
        maxLength={1000}
      />
    </div>
  );
};

const GroupAStep = () => {
  const { t } = useI18n();
  const { data, update } = useSubmission();
  const a = data.groupA;
  const set = (patch: Partial<typeof a>) => update("groupA", { ...a, ...patch });

  const forms: { value: typeof a.wasteForm; label: string }[] = [
    { value: "powder", label: t.quest.aFormPowder },
    { value: "stones", label: t.quest.aFormStones },
    { value: "liquid", label: t.quest.aFormLiquid },
    { value: "other", label: t.quest.aFormOther },
  ];

  return (
    <div className="space-y-4">
      <div className="space-y-1.5">
        <Label className="text-sm">{t.quest.aWasteType}</Label>
        <Input value={a.wasteType} onChange={(e) => set({ wasteType: e.target.value })} maxLength={200} />
      </div>

      <div className="space-y-1.5">
        <Label className="text-sm">{t.quest.aWasteForm}</Label>
        <RadioGroup
          value={a.wasteForm}
          onValueChange={(v) => set({ wasteForm: v as typeof a.wasteForm })}
          className="grid grid-cols-2 gap-2"
        >
          {forms.map((f) => (
            <label
              key={f.value}
              className="flex items-center gap-2 p-3 rounded-lg border border-border hover:bg-accent/50 cursor-pointer"
            >
              <RadioGroupItem value={f.value as string} />
              <span className="text-sm">{f.label}</span>
            </label>
          ))}
        </RadioGroup>
      </div>

      <div className="space-y-1.5">
        <Label className="text-sm">{t.quest.aHasAnalysis}</Label>
        <YesNo value={a.hasAnalysis} onChange={(v) => set({ hasAnalysis: v })} />
      </div>

      <div className="space-y-1.5">
        <Label className="text-sm">{t.quest.aMonthly}</Label>
        <Input
          type="number"
          min={0}
          step="0.1"
          value={a.monthlyTons}
          onChange={(e) => set({ monthlyTons: e.target.value })}
        />
      </div>

      <p className="text-xs text-muted-foreground bg-muted rounded-lg p-3">{t.quest.aUploadsNote}</p>
    </div>
  );
};

const GroupBStep = () => {
  const { t } = useI18n();
  const { data, update } = useSubmission();
  const b = data.groupB;
  const set = (patch: Partial<typeof b>) => update("groupB", { ...b, ...patch });

  return (
    <div className="space-y-4">
      <div className="space-y-1.5">
        <Label className="text-sm">{t.quest.bRawMaterials}</Label>
        <Textarea value={b.rawMaterials} onChange={(e) => set({ rawMaterials: e.target.value })} rows={2} maxLength={500} />
      </div>

      <div className="space-y-1.5">
        <Label className="text-sm">{t.quest.bInterest}</Label>
        <YesNo value={b.interest} onChange={(v) => set({ interest: v })} />
      </div>

      <div className="space-y-1.5">
        <Label className="text-sm">{t.quest.bReplace}</Label>
        <Input value={b.replaceMaterials} onChange={(e) => set({ replaceMaterials: e.target.value })} maxLength={300} />
      </div>

      <div className="space-y-1.5">
        <Label className="text-sm">{t.quest.bAnalysisAvail}</Label>
        <YesNo value={b.analysisAvail} onChange={(v) => set({ analysisAvail: v })} />
      </div>

      <div className="space-y-1.5">
        <Label className="text-sm">{t.quest.bSpecificInterest}</Label>
        <Input value={b.specificInterest} onChange={(e) => set({ specificInterest: e.target.value })} maxLength={300} />
      </div>

      <div className="space-y-1.5">
        <Label className="text-sm">{t.quest.bSourceIdentified}</Label>
        <YesNo value={b.sourceIdentified} onChange={(v) => set({ sourceIdentified: v })} />
      </div>

      <div className="space-y-1.5">
        <Label className="text-sm">{t.quest.bNotes}</Label>
        <Textarea value={b.notes} onChange={(e) => set({ notes: e.target.value })} rows={3} maxLength={1000} />
      </div>
    </div>
  );
};

const ContactStep = () => {
  const { t } = useI18n();
  const { data, update } = useSubmission();
  const ct = data.contact;
  const set = (patch: Partial<typeof ct>) => update("contact", { ...ct, ...patch });
  const emailErr = ct.email.length > 0 && !isValidEmail(ct.email);
  const phoneErr = ct.phone.length > 0 && !isValidPhone(ct.phone);

  return (
    <div className="space-y-4">
      <div>
        <h2 className="text-lg font-semibold text-primary-deep">{t.contact.title}</h2>
        <p className="text-sm text-muted-foreground mt-1">{t.contact.message}</p>
      </div>

      <div className="space-y-1.5">
        <Label className="text-sm">{t.contact.phone}</Label>
        <Input
          type="tel"
          value={ct.phone}
          onChange={(e) => set({ phone: e.target.value })}
          placeholder="+31 6 1234 5678"
          maxLength={30}
          aria-invalid={phoneErr}
          className={phoneErr ? "border-destructive" : ""}
        />
        {phoneErr && <p className="text-xs text-destructive">{t.contact.phoneInvalid}</p>}
      </div>

      <div className="space-y-1.5">
        <Label className="text-sm">{t.contact.email}</Label>
        <Input
          type="email"
          value={ct.email}
          onChange={(e) => set({ email: e.target.value })}
          placeholder="you@company.com"
          maxLength={255}
          aria-invalid={emailErr}
          className={emailErr ? "border-destructive" : ""}
        />
        {emailErr && <p className="text-xs text-destructive">{t.contact.emailInvalid}</p>}
      </div>

      <label className="flex items-start gap-2 p-3 rounded-lg border border-border cursor-pointer">
        <Checkbox
          checked={ct.acceptedTerms}
          onCheckedChange={(v) => set({ acceptedTerms: v === true })}
          className="mt-0.5"
        />
        <span className="text-sm text-muted-foreground">{t.contact.terms}</span>
      </label>
    </div>
  );
};

// =================== Small helpers ===================

const CheckRow = ({
  label,
  checked,
  onChange,
}: {
  label: string;
  checked: boolean;
  onChange: (v: boolean) => void;
}) => (
  <label className="flex items-center gap-2 p-3 rounded-lg border border-border hover:bg-accent/50 cursor-pointer">
    <Checkbox checked={checked} onCheckedChange={(v) => onChange(v === true)} />
    <span className="text-sm">{label}</span>
  </label>
);

const YesNo = ({
  value,
  onChange,
}: {
  value: "yes" | "no" | "";
  onChange: (v: "yes" | "no") => void;
}) => {
  const { t } = useI18n();
  return (
    <RadioGroup
      value={value}
      onValueChange={(v) => onChange(v as "yes" | "no")}
      className="grid grid-cols-2 gap-2"
    >
      {(["yes", "no"] as const).map((v) => (
        <label
          key={v}
          className="flex items-center justify-center gap-2 p-3 rounded-lg border border-border hover:bg-accent/50 cursor-pointer"
        >
          <RadioGroupItem value={v} />
          <span className="text-sm">{v === "yes" ? t.quest.yes : t.quest.no}</span>
        </label>
      ))}
    </RadioGroup>
  );
};

export default Questionnaire;
