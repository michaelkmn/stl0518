import { Link } from "react-router-dom";
import { Layout } from "@/components/Layout";
import { useI18n } from "@/i18n/I18nProvider";
import { Button } from "@/components/ui/button";
import { CheckCircle2 } from "lucide-react";
import { useEffect } from "react";
import { useSubmission } from "@/state/SubmissionContext";

const ThankYou = () => {
  const { t } = useI18n();
  const { reset } = useSubmission();

  // Clear the saved submission so the next visitor starts fresh.
  useEffect(() => {
    reset();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <Layout>
      <div className="container max-w-xl py-24 text-center">
        <div className="mx-auto w-20 h-20 rounded-full bg-primary/10 text-primary flex items-center justify-center mb-6">
          <CheckCircle2 className="w-10 h-10" />
        </div>
        <h1 className="text-3xl md:text-4xl font-bold text-primary-deep mb-4">{t.thanks.title}</h1>
        <p className="text-muted-foreground mb-8">{t.thanks.message}</p>
        <Button asChild className="bg-primary hover:bg-primary-deep">
          <Link to="/">{t.thanks.back}</Link>
        </Button>
      </div>
    </Layout>
  );
};

export default ThankYou;
