import { Link } from "react-router-dom";
import { Layout } from "@/components/Layout";
import { useI18n } from "@/i18n/I18nProvider";
import { Button } from "@/components/ui/button";
import { Recycle, Building2, ArrowRight, Leaf, ListChecks, MessageSquare, Factory } from "lucide-react";
import SliderCU, { Slide } from "@/components/Slider";
import HoverMenu from "@/components/HoverMenu/HoverMenu";
import { basicMenuItems } from "@/components/HoverMenu/list";
import SimpleMenu from "@/components/SimpleMenu";
import slidesData from "./slidesData";

const Index = () => {
  const { t } = useI18n();

  return (
    <Layout>
      <div className="absolute inset-0 bg-gradient-soft" />
      <div className="absolute -top-32 -right-32 w-96 h-96 rounded-full bg-primary/10 blur-3xl" />
      <div className="absolute -bottom-20 -left-20 w-72 h-72 rounded-full bg-primary-glow/15 blur-3xl" />
      <section className="relative overflow-hidden">
        <SimpleMenu />


        <div className="mt-5">

          <SliderCU slides={slidesData} autoPlay />
        </div>

        <div className="container* relative py-20 md:py-28 grid md:grid-cols-2 gap-12 items-center">
          <div>
            <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-accent text-accent-foreground text-xs font-semibold mb-6">
              <Leaf className="w-3.5 h-3.5" /> {t.hero.tagline}
            </span>
            <h1 className="text-4xl md:text-6xl font-bold tracking-tight text-primary-deep leading-[1.1]">
              {t.hero.title}
            </h1>
            <p className="mt-6 text-lg text-muted-foreground max-w-xl">{t.hero.subtitle}</p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Button size="lg" asChild className="bg-primary hover:bg-primary-deep shadow-elegant">
                <Link to="/select">
                  {t.hero.ctaPrimary} <ArrowRight className="ml-1" />
                </Link>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <a href="#how">{t.hero.ctaSecondary}</a>
              </Button>
            </div>
          </div>

          <div className="relative">
            <div className="aspect-square rounded-3xl bg-gradient-hero shadow-elegant p-8 flex items-center justify-center">
              <div className="grid grid-cols-2 gap-4 w-full">
                <Tile icon={<Factory />} label="Group A" sublabel="Waste Generators" tone="grey" />
                <Tile icon={<Building2 />} label="Group B" sublabel="Waste Re-users" tone="green" />
                <Tile icon={<Recycle />} label="Reuse" sublabel="Circular flow" tone="green" />
                <Tile icon={<Leaf />} label="NL" sublabel="Netherlands focus" tone="grey" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* How */}
      <section id="how" className="container* py-20 scroll-mt-20">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <h2 className="text-3xl md:text-4xl font-bold text-primary-deep">{t.how.title}</h2>
          <p className="mt-3 text-muted-foreground">{t.how.subtitle}</p>
        </div>
        <div className="grid md:grid-cols-3 gap-6">
          <Step n="1" title={t.how.s1Title} desc={t.how.s1Desc} icon={<ListChecks />} />
          <Step n="2" title={t.how.s2Title} desc={t.how.s2Desc} icon={<Building2 />} />
          <Step n="3" title={t.how.s3Title} desc={t.how.s3Desc} icon={<MessageSquare />} />
        </div>

        <div className="mt-12 text-center">
          <Button size="lg" asChild className="bg-primary hover:bg-primary-deep shadow-elegant">
            <Link to="/select">
              {t.hero.ctaPrimary} <ArrowRight className="ml-1" />
            </Link>
          </Button>
        </div>
      </section>
    </Layout>
  );
};

const Tile = ({
  icon,
  label,
  sublabel,
  tone,
}: {
  icon: React.ReactNode;
  label: string;
  sublabel: string;
  tone: "grey" | "green";
}) => (
  <div
    className={`rounded-2xl p-4 backdrop-blur ${tone === "grey"
      ? "bg-background/15 text-primary-foreground border border-white/10"
      : "bg-background/25 text-primary-foreground border border-white/20"
      }`}
  >
    <div className="w-9 h-9 rounded-lg bg-background/20 flex items-center justify-center mb-2">{icon}</div>
    <div className="text-sm font-bold">{label}</div>
    <div className="text-xs opacity-80">{sublabel}</div>
  </div>
);

const Step = ({ n, title, desc, icon }: { n: string; title: string; desc: string; icon: React.ReactNode }) => (
  <div className="bg-gradient-card rounded-2xl p-7 shadow-soft border border-border/40 transition-smooth hover:shadow-elegant hover:-translate-y-1">
    <div className="flex items-center gap-3 mb-4">
      <div className="w-10 h-10 rounded-xl bg-primary text-primary-foreground flex items-center justify-center">
        {icon}
      </div>
      <span className="text-3xl font-bold text-primary/30">{n}</span>
    </div>
    <h3 className="text-xl font-semibold text-primary-deep mb-2">{title}</h3>
    <p className="text-sm text-muted-foreground leading-relaxed">{desc}</p>
  </div>
);

export default Index;


