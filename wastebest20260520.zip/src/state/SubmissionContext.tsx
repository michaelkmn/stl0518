import { createContext, useContext, useEffect, useState, ReactNode } from "react";

export type Group = "A" | "B";
export type Region = "N" | "S" | "E" | "W";

export interface Responsibility {
  owner: boolean;
  rd: boolean;
  hse: boolean;
  other: boolean;
  otherText: string;
}

export interface CommonAnswers {
  responsibility: Responsibility;
  subcategory: string;
  region: Region | "";
  municipality: string;
  postal: string;
  products: string;
}

export interface GroupAAnswers {
  wasteType: string;
  wasteForm: "powder" | "stones" | "liquid" | "other" | "";
  hasAnalysis: "yes" | "no" | "";
  monthlyTons: string;
}

export interface GroupBAnswers {
  rawMaterials: string;
  interest: "yes" | "no" | "";
  replaceMaterials: string;
  analysisAvail: "yes" | "no" | "";
  specificInterest: string;
  sourceIdentified: "yes" | "no" | "";
  notes: string;
}

export interface Contact {
  phone: string;
  email: string;
  acceptedTerms: boolean;
}

export interface Submission {
  group: Group | null;
  common: CommonAnswers;
  groupA: GroupAAnswers;
  groupB: GroupBAnswers;
  contact: Contact;
}

const empty: Submission = {
  group: null,
  common: {
    responsibility: { owner: false, rd: false, hse: false, other: false, otherText: "" },
    subcategory: "",
    region: "",
    municipality: "",
    postal: "",
    products: "",
  },
  groupA: { wasteType: "", wasteForm: "", hasAnalysis: "", monthlyTons: "" },
  groupB: {
    rawMaterials: "",
    interest: "",
    replaceMaterials: "",
    analysisAvail: "",
    specificInterest: "",
    sourceIdentified: "",
    notes: "",
  },
  contact: { phone: "", email: "", acceptedTerms: false },
};

interface Ctx {
  data: Submission;
  setGroup: (g: Group) => void;
  update: <K extends keyof Submission>(key: K, value: Submission[K]) => void;
  reset: () => void;
}

const C = createContext<Ctx | null>(null);
const KEY = "grecom_submission_v1";

export const SubmissionProvider = ({ children }: { children: ReactNode }) => {
  const [data, setData] = useState<Submission>(() => {
    try {
      const raw = localStorage.getItem(KEY);
      return raw ? { ...empty, ...JSON.parse(raw) } : empty;
    } catch {
      return empty;
    }
  });

  useEffect(() => {
    localStorage.setItem(KEY, JSON.stringify(data));
  }, [data]);

  const setGroup = (g: Group) => setData((d) => ({ ...d, group: g }));
  const update: Ctx["update"] = (key, value) => setData((d) => ({ ...d, [key]: value }));
  const reset = () => setData(empty);

  return <C.Provider value={{ data, setGroup, update, reset }}>{children}</C.Provider>;
};

export const useSubmission = () => {
  const ctx = useContext(C);
  if (!ctx) throw new Error("useSubmission must be used within SubmissionProvider");
  return ctx;
};
