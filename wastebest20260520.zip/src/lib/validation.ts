import { z } from "zod";

export const postalRegex = /^\d{4}[A-Z]{2}$/;
export const isValidPostal = (v: string) => postalRegex.test(v.trim());

export const emailSchema = z.string().trim().email();
export const isValidEmail = (v: string) => emailSchema.safeParse(v).success;

// Permissive international phone: digits, spaces, +, -, ()  — 7 to 20 chars
export const phoneRegex = /^[+\d][\d\s().-]{6,19}$/;
export const isValidPhone = (v: string) => phoneRegex.test(v.trim());
