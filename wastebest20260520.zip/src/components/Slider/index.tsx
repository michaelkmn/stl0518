import React, { useState, useEffect, useCallback, ReactNode } from 'react';
import './Slider.css';

// Type definitions
export interface Slide {
  url: string;
  caption?: string;
  type: 'image' | 'video';
}

interface SliderProps {
  slides: Slide[];
  autoPlay?: boolean;
  autoPlayDelay?: number;
  height?: string | number;
  showArrows?: boolean;
  showDots?: boolean;
}

const SliderCU: React.FC<SliderProps> = ({
  slides,
  autoPlay = true,
  autoPlayDelay = 3000,
  height = '500px',
  showArrows = true,
  showDots = true,
}) => {
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(autoPlay);
  const [touchStart, setTouchStart] = useState<number | null>(null);

  const goToPrevious = useCallback((): void => {
    setCurrentIndex((prevIndex: number) =>
      prevIndex === 0 ? slides.length - 1 : prevIndex - 1
    );
  }, [slides.length]);

  const goToNext = useCallback((): void => {
    setCurrentIndex((prevIndex: number) =>
      prevIndex === slides.length - 1 ? 0 : prevIndex + 1
    );
  }, [slides.length]);

  const goToSlide = (index: number): void => {
    if (index >= 0 && index < slides.length) {
      setCurrentIndex(index);
    }
  };

  // Auto-play logic
  useEffect(() => {
    if (!isPlaying || slides.length === 0) return;

    const intervalId: NodeJS.Timeout = setInterval(() => {
      goToNext();
    }, autoPlayDelay);

    return () => clearInterval(intervalId);
  }, [isPlaying, goToNext, autoPlayDelay, slides.length]);

  // Pause auto-play on hover
  const handleMouseEnter = (): void => setIsPlaying(false);
  const handleMouseLeave = (): void => setIsPlaying(autoPlay);

  // Touch events for mobile swipe
  const handleTouchStart = (e: React.TouchEvent): void => {
    setTouchStart(e.touches[0].clientX);
  };

  const handleTouchEnd = (e: React.TouchEvent): void => {
    if (touchStart === null) return;

    const touchEnd = e.changedTouches[0].clientX;
    const diff = touchStart - touchEnd;

    if (Math.abs(diff) > 50) {
      if (diff > 0) {
        goToNext();
      } else {
        goToPrevious();
      }
    }
    setTouchStart(null);
  };

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent): void => {
      if (e.key === 'ArrowLeft') {
        goToPrevious();
      } else if (e.key === 'ArrowRight') {
        goToNext();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [goToPrevious, goToNext]);

  if (!slides || slides.length === 0) {
    return <div className="slider-container">No slides provided</div>;
  }

  const containerStyle = {
    height: typeof height === 'number' ? `${height}px` : height
  };

  return (
    <div
      className="slider-container"
      style={containerStyle}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      onTouchStart={handleTouchStart}
      onTouchEnd={handleTouchEnd}
    >
      <div className="slider">
        {slides.map((slide: Slide, index: number) => (
          <div
            key={index}
            className={`slide ${index === currentIndex ? 'active' : ''}`}
            style={{ transform: `translateX(${100 * (index - currentIndex)}%)` }}
          >
            {slide.type === 'video' ? (
              <video
                src={slide.url}
                controls
                autoPlay={index === currentIndex}
                muted
                loop
                playsInline
                className="media"
              />
            ) : (
              <img
                src={slide.url}
                alt={slide.caption || `Slide ${index + 1}`}
                className="media"
                loading="lazy"

                />
            )}
            {slide.caption && <div className="caption">{slide.caption}</div>}
          </div>
        ))}
      </div>

      {/* Navigation Arrows */}
      {showArrows && slides.length > 1 && (
        <>
          <button
            className="slider-btn prev"
            onClick={goToPrevious}
            aria-label="Previous slide"
          >
            &#10094;
          </button>
          <button
            className="slider-btn next"
            onClick={goToNext}
            aria-label="Next slide"
          >
            &#10095;
          </button>
        </>
      )}

      {/* Dots / Indicators */}
      {showDots && slides.length > 1 && (
        <div className="dots-container">
          {slides.map((_: Slide, index: number) => (
            <button
              key={index}
              className={`dot ${index === currentIndex ? 'active' : ''}`}
              onClick={() => goToSlide(index)}
              aria-label={`Go to slide ${index + 1}`}
            />
          ))}
        </div>
      )}
    </div>
  );
};

export default SliderCU;