import { Link } from "react-router-dom";
import { Logo } from "./Logo";
import { useI18n } from "@/i18n/I18nProvider";
import { Globe } from "lucide-react";

export const Header = () => {
  const { lang, setLang } = useI18n();

  return (
    <header className="sticky top-0 z-40 w-full border-b border-border/60 bg-background/80 backdrop-blur-md">
      <div className="container flex h-16 items-center justify-between">
        <Link to="/" className="flex items-center" aria-label="GreCoM home">
          <Logo />
        </Link>

        <button
          onClick={() => setLang(lang === "en" ? "nl" : "en")}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-semibold text-muted-foreground hover:text-primary hover:bg-accent transition-smooth"
          aria-label="Toggle language"
        >
          <Globe className="w-4 h-4" />
          {lang.toUpperCase()}
        </button>
      </div>
    </header>
  );
};
