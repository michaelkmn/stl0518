import logo from "@/assets/grecom-logo.jpg";

export const Logo = ({ size = 40, withText = true }: { size?: number; withText?: boolean }) => (
  <div className="flex items-center gap-2">
    <img src={logo} alt="GreCoM logo" width={size} height={size} className="rounded-full object-cover" style={{ width: size, height: size }} />
    {withText && <span className="font-bold text-lg tracking-tight text-primary-deep">GreCoM</span>}
  </div>
);
