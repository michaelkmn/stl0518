import { TSimpleMenuItem } from "./item";

const list: TSimpleMenuItem[] = [
    {
        value: 'Home',
    },    
    {
        value: 'Products / Services',
        children:
            [
                { 
                    value: 'Green Construction Materials',
                    children: [
                        { value: 'GREEN paver' },
                        { value: 'Green Block' },
                        { value: 'Green Expose' },
                    ]                                
                },
                { value: 'GreM platform' },
                { value: 'Consulation' },
                { value: 'Redesigning and Renovation' },
            ]
    },
    {
        value: 'About Us',
        children:
        [
            { value: 'Our Team' },
            { value: 'Certifications & Licenses' },
            { value: 'Partners' },
        ]
    },
    {
        value: 'Contact us',
        children:
            [
                { value: 'Request a consulation' },
                { value: 'Contact form' },
                { value: 'Address' },
                { value: 'Tel' },
                { value: 'LinkedIn' },
                { value: 'Email' },
            ]
    },
    
]


export default list