import React from 'react';

interface VerticalDividerProps {
  height?: number;
  color?: string;
  className?: string;
}

const VerticalDivider: React.FC<VerticalDividerProps> = ({ 
  height = 6, 
  color = 'gray-300',
  className = '' 
}) => {
  return (
    <div 
      className={` mx-2 ${className} border-2 border-${color} rounded-full  `}
      style={{ height: `${height * 4}px` }}
    />
  );
};

export default VerticalDivider;