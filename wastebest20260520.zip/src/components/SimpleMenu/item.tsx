import { Play } from "lucide-react";

export interface TSimpleMenuItem {
    value?: string;
    divider?: boolean;
    children?: TSimpleMenuItem[];
    depth?: number; 
}

const SimpleMenuItem = (props: TSimpleMenuItem) => {
    const { value, divider, children, depth = 0 } = props || {};
    const hasChildren = children && children.length > 0;

    const subMenuPosition = depth === 0 
        ? "left-0 top-full mt-1" 
        : "left-full top-0 ml-1";

    return (
        <div className="relative group">
            <div className="flex flex-row items-center gap-2 hover:scale-105 hover:shadow-lg transition-all duration-300 mb-1 cursor-pointer border-2 border-gray-200 rounded-md p-2">
                <h1 className="flex-1 whitespace-nowrap">{value}</h1>
                {hasChildren && <Play size={15} className="flex-shrink-0" />}
            </div>

            {hasChildren && (
                <div className={`absolute ${subMenuPosition} bg-white shadow-lg rounded-md min-w-full z-50 hidden group-hover:block`}>
                    {children.map((child, index) => (
                        <SimpleMenuItem 
                            key={index} 
                            {...child} 
                            depth={depth + 1} 
                        />
                    ))}
                </div>
            )}
        </div>
    );
};

export default SimpleMenuItem;
