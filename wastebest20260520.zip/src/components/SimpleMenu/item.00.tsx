import { Play } from "lucide-react";
import VerticalDivider from "./VerticalDivider";

const SimpleMenuItem = (props: TSimpleMenuItem) => {
    const { value, divider, children } = props || {}
    const hasChildren = children && children.length > 0



    return (
        <div className="relative group">
            <div className="flex flex-row items-center gap-2 hover:scale-105 hover:shadow-lg transition-all duration-300  mb-1 cursor-pointer border-2 border-gray-200 rounded-md p-2">
                <h1 className="flex-1">{value}</h1>
                {hasChildren && <Play size={15} className="flex-shrink-0" />}
                {/* {divider && <VerticalDivider height={6} color="red-100" />} */}
            </div>

            {/* Submenu - pure Tailwind, no JS */}
            {hasChildren && (
                <div className="absolute left-0 top-full mtc-1 bg-white shadow-lg rounded-md min-w-full z-10 hidden group-hover:block">
                    {children.map((child, index) => (
                        <SimpleMenuItem key={index} {...child} />
                    ))}
                </div>
            )}
        </div>
    )
}

export default SimpleMenuItem



export interface TSimpleMenuItem {

    value?: string;
    divider?: boolean;
    children?: TSimpleMenuItem[]
} 