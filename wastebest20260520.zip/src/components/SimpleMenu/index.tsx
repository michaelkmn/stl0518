import HorizontalContainer from "./Container"
import SimpleMenuItem from "./item"
import list from "./list"

const SimpleMenu = () => {

    return (
        <div className="flex flex-row py-5">
            <HorizontalContainer gradient="custom" shadow="lg">
                {list.map((item, index) => <SimpleMenuItem {...item} divider={index + 1 < list.length} />)}
            </HorizontalContainer>

        </div>
    )
}
export default SimpleMenu