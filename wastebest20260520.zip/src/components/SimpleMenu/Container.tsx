import React from 'react';

interface HorizontalContainerProps {
  children: React.ReactNode;
  gradient?:'green'| 'blue' | 'purple' | 'pink' | 'orange' | 'gray' | 'custom';
  shadow?: 'none' | 'sm' | 'md' | 'lg' | 'xl';
  rounded?: boolean;
  padding?: 'sm' | 'md' | 'lg';
  className?: string;
}

const HorizontalContainer: React.FC<HorizontalContainerProps> = ({
  children,
  gradient = 'blue',
  shadow = 'md',
  rounded = true,
  padding = 'md',
  className = ''
}) => {
  const gradientClasses = {
    blue: 'bg-gradient-to-r from-blue-500 to-blue-600',
    green: 'bg-gradient-to-r from-green-100 to-green-200',
    purple: 'bg-gradient-to-r from-purple-500 to-purple-600',
    pink: 'bg-gradient-to-r from-pink-500 to-pink-600',
    orange: 'bg-gradient-to-r from-orange-500 to-orange-600',
    gray: 'bg-gradient-to-r from-gray-700 to-gray-800',
    custom: ''
  };

  const shadowClasses = {
    none: '',
    sm: 'shadow-sm',
    md: 'shadow-md',
    lg: 'shadow-lg',
    xl: 'shadow-xl'
  };

  const paddingClasses = {
    sm: 'px-4 py-2',
    md: 'px-6 py-3',
    lg: 'px-8 py-4'
  };

  return (
    <div
      className={`
        ${gradientClasses[gradient]}
        ${shadowClasses[shadow]}
        ${paddingClasses[padding]}
        ${rounded ? 'rounded-lg' : ''}
        flex items-center space-x-6
        ${className}
      `}
    >
      {children}
    </div>
  );
};

export default HorizontalContainer;