import { useI18n } from "@/i18n/I18nProvider";
import { Logo } from "./Logo";

export const Footer = () => {
  const { t } = useI18n();
  return (
    <footer className="border-t border-border/60 bg-muted/40 mt-16">
      <div className="container py-10 flex flex-col md:flex-row items-center justify-between gap-4">
        <Logo size={32} />
        <p className="text-sm text-muted-foreground text-center md:text-right">{t.footer}</p>
      </div>
    </footer>
  );
};
