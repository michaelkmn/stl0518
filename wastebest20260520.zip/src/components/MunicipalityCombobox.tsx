import { useState } from "react";
import { Check, ChevronsUpDown } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import municipalities from "@/lib/nlMunicipalities.json";

interface Props {
  value: string;
  onChange: (v: string) => void;
  placeholder: string;
  searchPlaceholder: string;
}

export const MunicipalityCombobox = ({ value, onChange, placeholder, searchPlaceholder }: Props) => {
  const [open, setOpen] = useState(false);
  const list = municipalities as string[];

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          role="combobox"
          aria-expanded={open}
          className={cn("w-full justify-between font-normal", !value && "text-muted-foreground")}
        >
          {value || placeholder}
          <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-[--radix-popover-trigger-width] p-0 bg-popover" align="start">
        <Command>
          <CommandInput placeholder={searchPlaceholder} />
          <CommandList>
            <CommandEmpty>—</CommandEmpty>
            <CommandGroup>
              {list.map((m) => (
                <CommandItem
                  key={m}
                  value={m}
                  onSelect={(currentValue) => {
                    // CommandItem normalizes value to lowercase; find original
                    const original = list.find((x) => x.toLowerCase() === currentValue.toLowerCase()) || m;
                    onChange(original);
                    setOpen(false);
                  }}
                >
                  <Check className={cn("mr-2 h-4 w-4", value === m ? "opacity-100" : "opacity-0")} />
                  {m}
                </CommandItem>
              ))}
            </CommandGroup>
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  );
};
