import React, { useState, useRef, useEffect, useCallback } from 'react';
import './HoverMenu.css';

export interface AdvancedMenuItem {
  id: string | number;
  label: string;
  icon?: React.ReactNode;
  shortcut?: string;
  href?: string;
  onClick?: () => void;
  disabled?: boolean;
  divider?: boolean;
  badge?: string | number;
  badgeColor?: string;
  children?: AdvancedMenuItem[];
}

interface AdvancedHoverMenuProps {
  trigger: React.ReactNode;
  items: AdvancedMenuItem[];
  position?: 'top' | 'bottom' | 'left' | 'right';
  align?: 'start' | 'center' | 'end';
  width?: number | string;
  animation?: 'fade' | 'slide' | 'scale' | 'none';
  delay?: number;
  closeOnClick?: boolean;
  showIcons?: boolean;
  theme?: 'light' | 'dark' | 'auto';
  className?: string;
}

const AdvancedHoverMenu: React.FC<AdvancedHoverMenuProps> = ({
  trigger,
  items,
  position = 'bottom',
  align = 'start',
  width = 220,
  animation = 'fade',
  delay = 200,
  closeOnClick = true,
  showIcons = true,
  theme = 'light',
  className = '',
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [openSubmenu, setOpenSubmenu] = useState<string | number | null>(null);
  const timeoutRef = useRef<NodeJS.Timeout>();
  const menuRef = useRef<HTMLDivElement>(null);

  const handleMouseEnter = useCallback(() => {
    if (timeoutRef.current) clearTimeout(timeoutRef.current);
    setIsOpen(true);
  }, []);

  const handleMouseLeave = useCallback(() => {
    timeoutRef.current = setTimeout(() => {
      setIsOpen(false);
      setOpenSubmenu(null);
    }, delay);
  }, [delay]);

  const handleItemClick = (item: AdvancedMenuItem) => {
    if (item.disabled) return;
    if (item.onClick) item.onClick();
    if (closeOnClick && !item.children) {
      setIsOpen(false);
    }
  };

  useEffect(() => {
    return () => {
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
    };
  }, []);

  const getAnimationClass = () => {
    if (animation === 'none') return '';
    return `animate-${animation}`;
  };

  const getThemeClass = () => {
    if (theme === 'auto') {
      return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'theme-dark' : 'theme-light';
    }
    return `theme-${theme}`;
  };

  const renderMenuItem = (item: AdvancedMenuItem, depth: number = 0): React.ReactNode => {
    if (item.divider) {
      return <div key={item.id} className="menu-divider" />;
    }

    const hasChildren = item.children && item.children.length > 0;
    const isSubmenuOpen = openSubmenu === item.id;

    return (
      <div
        key={item.id}
        className={`menu-item-wrapper ${item.disabled ? 'disabled' : ''}`}
        onMouseEnter={() => hasChildren && setOpenSubmenu(item.id)}
        onMouseLeave={() => hasChildren && setOpenSubmenu(null)}
      >
        <div
          className="menu-item"
          onClick={() => handleItemClick(item)}
        >
          {showIcons && item.icon && <span className="menu-icon">{item.icon}</span>}
          <span className="menu-label">{item.label}</span>
          {item.shortcut && <span className="menu-shortcut">{item.shortcut}</span>}
          {item.badge && (
            <span 
              className="menu-badge" 
              style={{ backgroundColor: item.badgeColor || '#ff4444' }}
            >
              {item.badge}
            </span>
          )}
          {hasChildren && <span className="menu-arrow">›</span>}
        </div>
        
        {hasChildren && isSubmenuOpen && (
          <div className={`submenu submenu-depth-${depth + 1}`}>
            {item.children!.map(child => renderMenuItem(child, depth + 1))}
          </div>
        )}
      </div>
    );
  };

  return (
    <div
      className={`advanced-hover-menu ${getThemeClass()} ${className}`}
      ref={menuRef}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
    >
      <div className="menu-trigger">
        {trigger}
      </div>
      
      {isOpen && (
        <div
          className={`menu-dropdown position-${position} align-${align} ${getAnimationClass()}`}
          style={{
            width: typeof width === 'number' ? `${width}px` : width,
          }}
        >
          <div className="menu-items">
            {items.map(item => renderMenuItem(item))}
          </div>
        </div>
      )}
    </div>
  );
};

export default AdvancedHoverMenu;