import React, { useState, useRef, useEffect, useCallback } from 'react';
import './HoverMenu.css';

// Type definitions
export interface MenuItem {
  id: string | number;
  label?: string;
  icon?: React.ReactNode;
  href?: string;
  onClick?: () => void;
  disabled?: boolean;
  divider?: boolean;
  children?: MenuItem[];
}

export interface HoverMenuProps {
  trigger: React.ReactNode;
  items: MenuItem[];
  position?: 'top' | 'bottom' | 'left' | 'right';
  align?: 'start' | 'center' | 'end';
  width?: number | string;
  delay?: number;
  closeOnClick?: boolean;
  closeOnItemClick?: boolean;
  className?: string;
  triggerClassName?: string;
  menuClassName?: string;
  disabled?: boolean;
  arrow?: boolean;
  maxHeight?: string | number;
}

const HoverMenu: React.FC<HoverMenuProps> = ({
  trigger,
  items,
  position = 'bottom',
  align = 'start',
  width = 200,
  delay = 300,
  closeOnClick = true,
  closeOnItemClick = true,
  className = '',
  triggerClassName = '',
  menuClassName = '',
  disabled = false,
  arrow = true,
  maxHeight = '400px',
}) => {
  const [isOpen, setIsOpen] = useState<boolean>(false);
  const [openSubmenu, setOpenSubmenu] = useState<string | number | null>(null);
  const hoverTimeoutRef = useRef<NodeJS.Timeout>();
  const menuRef = useRef<HTMLDivElement>(null);
  const triggerRef = useRef<HTMLDivElement>(null);

  const handleMouseEnter = useCallback((): void => {
    if (disabled) return;
    if (hoverTimeoutRef.current) clearTimeout(hoverTimeoutRef.current);
    setIsOpen(true);
  }, [disabled]);

  const handleMouseLeave = useCallback((): void => {
    if (disabled) return;
    hoverTimeoutRef.current = setTimeout(() => {
      setIsOpen(false);
      setOpenSubmenu(null);
    }, delay);
  }, [disabled, delay]);

  const handleItemClick = (item: MenuItem): void => {
    if (item.disabled) return;
    
    if (item.onClick) {
      item.onClick();
    }
    
    if (closeOnItemClick && !item.children) {
      setIsOpen(false);
      setOpenSubmenu(null);
    }
  };

  const handleSubmenuMouseEnter = (itemId: string | number): void => {
    setOpenSubmenu(itemId);
  };

  const handleSubmenuMouseLeave = (): void => {
    setOpenSubmenu(null);
  };

  // Close menu when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent): void => {
      if (closeOnClick && 
          menuRef.current && 
          !menuRef.current.contains(event.target as Node) &&
          triggerRef.current &&
          !triggerRef.current.contains(event.target as Node)) {
        setIsOpen(false);
        setOpenSubmenu(null);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      if (hoverTimeoutRef.current) clearTimeout(hoverTimeoutRef.current);
    };
  }, [closeOnClick]);

  const getMenuPosition = (): React.CSSProperties => {
    const styles: React.CSSProperties = {
      width: typeof width === 'number' ? `${width}px` : width,
      maxHeight: typeof maxHeight === 'number' ? `${maxHeight}px` : maxHeight,
      overflowY: 'auto',
    };

    switch (position) {
      case 'bottom':
        styles.top = '100%';
        styles.left = align === 'start' ? '0' : align === 'end' ? 'auto' : '50%';
        styles.right = align === 'end' ? '0' : 'auto';
        styles.transform = align === 'center' ? 'translateX(-50%)' : 'none';
        styles.marginTop = '8px';
        break;
      case 'top':
        styles.bottom = '100%';
        styles.left = align === 'start' ? '0' : align === 'end' ? 'auto' : '50%';
        styles.right = align === 'end' ? '0' : 'auto';
        styles.transform = align === 'center' ? 'translateX(-50%)' : 'none';
        styles.marginBottom = '8px';
        break;
      case 'left':
        styles.right = '100%';
        styles.top = align === 'start' ? '0' : align === 'end' ? 'auto' : '50%';
        styles.bottom = align === 'end' ? '0' : 'auto';
        styles.transform = align === 'center' ? 'translateY(-50%)' : 'none';
        styles.marginRight = '8px';
        break;
      case 'right':
        styles.left = '100%';
        styles.top = align === 'start' ? '0' : align === 'end' ? 'auto' : '50%';
        styles.bottom = align === 'end' ? '0' : 'auto';
        styles.transform = align === 'center' ? 'translateY(-50%)' : 'none';
        styles.marginLeft = '8px';
        break;
    }

    return styles;
  };

  const renderMenuItem = (item: MenuItem, depth: number = 0): React.ReactNode => {
    if (item.divider) {
      return <div key={item.id} className="menu-divider" />;
    }

    const hasChildren = item.children && item.children.length > 0;
    const isSubmenuOpen = openSubmenu === item.id;

    return (
      <div
        key={item.id}
        className={`menu-item-wrapper ${item.disabled ? 'disabled' : ''}`}
        onMouseEnter={() => hasChildren && handleSubmenuMouseEnter(item.id)}
        onMouseLeave={hasChildren ? handleSubmenuMouseLeave : undefined}
      >
        <div
          className={`menu-item ${hasChildren ? 'has-children' : ''}`}
          onClick={() => handleItemClick(item)}
        >
          {item.icon && <span className="menu-icon">{item.icon}</span>}
          <span className="menu-label">{item.label}</span>
          {hasChildren && (
            <span className="menu-arrow">
              {position === 'left' || position === 'right' ? '▶' : '▼'}
            </span>
          )}
        </div>
        
        {hasChildren && isSubmenuOpen && (
          <div
            className={`submenu submenu-depth-${depth + 1}`}
            style={{
              position: 'absolute',
              left: position === 'right' ? '100%' : position === 'left' ? 'auto' : '0',
              right: position === 'left' ? '100%' : 'auto',
              top: 0,
              minWidth: typeof width === 'number' ? `${width}px` : width,
              marginLeft: position === 'right' ? '4px' : '0',
              marginRight: position === 'left' ? '4px' : '0',
            }}
          >
            {item.children!.map(child => renderMenuItem(child, depth + 1))}
          </div>
        )}
      </div>
    );
  };

  return (
    <div
      className={`hover-menu ${className}`}
      ref={menuRef}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
    >
      <div
        ref={triggerRef}
        className={`hover-menu-trigger ${triggerClassName} ${isOpen ? 'active' : ''}`}
      >
        {trigger}
      </div>
      
      {isOpen && !disabled && (
        <div
          className={`hover-menu-dropdown ${menuClassName} position-${position} align-${align}`}
          style={getMenuPosition()}
        >
          {arrow && <div className={`menu-arrow arrow-${position}`} />}
          <div className="menu-items">
            {items.map(item => renderMenuItem(item))}
          </div>
        </div>
      )}
    </div>
  );
};

export default HoverMenu;