import React from 'react';
import HoverMenu, { MenuItem } from './HoverMenu';
import AdvancedHoverMenu, { AdvancedMenuItem } from './AdvancedHoverMenu';
// import './App.css';

// Icons (you can use any icon library like react-icons, lucide-react, etc.)
const HomeIcon = () => <span>🏠</span>;
const UserIcon = () => <span>👤</span>;
const SettingsIcon = () => <span>⚙️</span>;
const LogoutIcon = () => <span>🚪</span>;
const FileIcon = () => <span>📄</span>;
const EditIcon = () => <span>✏️</span>;
const DeleteIcon = () => <span>🗑️</span>;
const ShareIcon = () => <span>📤</span>;


export const basicMenuItems: MenuItem[] = [
  { id: 1, label: 'Home', icon: <HomeIcon />, href: '/' },
  { id: 2, label: 'Profile', icon: <UserIcon />, onClick: () => console.log('Profile clicked') },
  { id: 3, label: 'Settings', icon: <SettingsIcon /> },
  { id: 4, divider: true },
  { id: 5, label: 'Logout', icon: <LogoutIcon />, onClick: () => console.log('Logout') },
];

// Nested menu items
// export const nestedMenuItems: MenuItem[] = [
//   {
//     id: 1,
//     label: 'File',
//     icon: <FileIcon />,
//     children: [
//       { id: 'new', label: 'New', shortcut: 'Ctrl+N' },
//       { id: 'open', label: 'Open', shortcut: 'Ctrl+O' },
//       { id: 'save', label: 'Save', shortcut: 'Ctrl+S' },
//       // { id: 'divider', divider: true },
//       { id: 'exit', label: 'Exit' },
//     ],
//   },
//   {
//     id: 2,
//     label: 'Edit',
//     icon: <EditIcon />,
//     children: [
//       { id: 'undo', label: 'Undo', shortcut: 'Ctrl+Z' },
//       { id: 'redo', label: 'Redo', shortcut: 'Ctrl+Y' },
//       { id: 'cut', label: 'Cut', shortcut: 'Ctrl+X' },
//       { id: 'copy', label: 'Copy', shortcut: 'Ctrl+C' },
//       { id: 'paste', label: 'Paste', shortcut: 'Ctrl+V' },
//     ],
//   },
//   {
//     id: 3,
//     label: 'Actions',
//     children: [
//       { id: 'share', label: 'Share', icon: <ShareIcon /> },
//       { id: 'delete', label: 'Delete', icon: <DeleteIcon />, disabled: true },
//     ],
//   },
// ];

// Advanced menu with badges and shortcuts
export const advancedMenuItems: AdvancedMenuItem[] = [
  {
    id: 1,
    label: 'Notifications',
    icon: '🔔',
    badge: 3,
    badgeColor: '#ff4444',
    onClick: () => console.log('Notifications'),
  },
  {
    id: 2,
    label: 'Messages',
    icon: '💬',
    badge: 12,
    badgeColor: '#4caf50',
    onClick: () => console.log('Messages'),
  },
  { id: 3, divider: true },
  {
    id: 4,
    label: 'Profile Settings',
    icon: '👤',
    shortcut: '⌘P',
    children: [
      { id: 'account', label: 'Account', shortcut: '⌘A' },
      { id: 'privacy', label: 'Privacy', shortcut: '⌘R' },
      { id: 'security', label: 'Security', shortcut: '⌘S' },
    ],
  },
  {
    id: 5,
    label: 'Appearance',
    icon: '🎨',
    children: [
      { id: 'light', label: 'Light Theme' },
      { id: 'dark', label: 'Dark Theme' },
      { id: 'auto', label: 'Auto Theme' },
    ],
  },
];




